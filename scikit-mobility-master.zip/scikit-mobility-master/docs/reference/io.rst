===================
Input/Output
===================
.. currentmodule:: skmob.io.file

.. autosummary::
	
	write
	read
	load_geolife_trajectories

.. automodule:: skmob.io.file
	:members: write, read, load_geolife_trajectories