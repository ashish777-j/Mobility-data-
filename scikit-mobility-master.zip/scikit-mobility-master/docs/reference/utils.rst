{{ header }}

.. _api.io:

============
Measures
blablablabla
============
.. currentmodule:: skmob

Collective Measures
~~~~~~~~~~~~~~~~~~~
.. autosummary::
   :toctree: measures
   
   collective.uncorrelated_location_entropy
   mean_square_displacement
   visits_per_location
   homes_per_location
   visits_per_time_unit
   origin_destination_matrix

   
