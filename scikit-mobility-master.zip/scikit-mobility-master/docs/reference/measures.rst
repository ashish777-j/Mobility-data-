
============
Measures
============

.. toctree::
   :caption: API Reference
   :maxdepth: 2

   collective_measures
   individual_measures
   evaluation_measures

